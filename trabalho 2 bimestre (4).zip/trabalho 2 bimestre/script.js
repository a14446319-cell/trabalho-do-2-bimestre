/* =======================================================
   1. ATUALIZAÇÃO AUTOMÁTICA DO MENU AO ROLAR A PÁGINA
   ======================================================= */
const sections = document.querySelectorAll("main, section"); // Adicionado main para abranger as seções
const navLinks = document.querySelectorAll("nav ul li a");

window.addEventListener("scroll", () => {
    let current = "";          

    sections.forEach(section => {
        const sectionTop = section.offsetTop - 120;
        if (window.scrollY >= sectionTop) {
            current = section.getAttribute("id");
        }
    });

    navLinks.forEach(link => {
        link.classList.remove("active");
        // Verifica se o href corresponde à seção atual na tela
        if (current && link.getAttribute("href") === "index.html#" + current || link.getAttribute("href") === "#" + current) {
            link.classList.add("active");
        }
    });
});

/* =======================================================
   2. ANIMAÇÃO DOS NÚMEROS E EFEITOS DE ROLAGEM
   ======================================================= */
document.addEventListener("DOMContentLoaded", () => {
    
    // Animação Progressiva dos Números dos Cards (Disparada ao Abrir)
    const indicators = document.querySelectorAll('.card[data-target]');
    
    const triggerCounters = () => {
        indicators.forEach(item => {
            const displayEl = item.querySelector('.stat-number');
            if (!displayEl) return; // Evita erros se o elemento não existir na página atual
            
            const finalValue = +item.getAttribute('data-target');
            let startValue = 0;
            
            const step = finalValue > 1000 ? Math.ceil(finalValue / 70) : 1;
            const refreshRate = finalValue > 1000 ? 15 : 60;

            const trackingInterval = setInterval(() => {
                startValue += step;
                if (startValue >= finalValue) {
                    clearInterval(trackingInterval);
                    displayEl.innerText = finalValue > 1000 ? "10.000+" : "15+";
                } else {
                    displayEl.innerText = finalValue > 1000 ? startValue.toLocaleString('pt-BR') : startValue;
                }
            }, refreshRate);
        });
    };

    // Pequeno atraso intencional na abertura para valorizar o efeito visual
    setTimeout(triggerCounters, 350);

    // Efeito Dinâmico de Aparição da Seção ao rolar a página
    const trackingElements = document.querySelectorAll('.scroll-element');
    
    const evaluateScrollPosition = () => {
        const viewportLimit = window.innerHeight * 0.88;

        trackingElements.forEach(element => {
            const elementTopOffset = element.getBoundingClientRect().top;
            if (elementTopOffset < viewportLimit) {
                element.classList.add('visible');
            }
        });
    };

    window.addEventListener('scroll', evaluateScrollPosition);
    evaluateScrollPosition(); // Execução preventiva inicial
});